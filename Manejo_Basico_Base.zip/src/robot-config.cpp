#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// Instrancia global del cerebro V5
brain Brain;

// Definición de variables
motor leftMotorA = motor(PORT11, ratio18_1, false);
motor leftMotorB = motor(PORT20, ratio18_1, false);
motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB);
motor rightMotorA = motor(PORT2, ratio18_1, true);
motor rightMotorB = motor(PORT9, ratio18_1, true);
motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB);
/*
vex::drivetrain::drivetrain 	( 	vex::motor &  	leftMotor,
                vex::motor &  	rightMotor,
                double  	wheelTravel = 319.1764,
                double  	trackWidth = 292.1,
                double  	wheelBase = 130,
                distanceUnits  	unit = distanceUnits::mm,
                double  	externalGearRatio = 1.0
        )

*/
drivetrain Base =
    drivetrain(LeftDriveSmart, RightDriveSmart, 319.19, 295, 40, mm, 1);
controller Controlador = controller(primary);
// Definir la tarea para manejar las entradas del control
int baseControl() {
  while (true) {
    if (Controlador.Axis2.position() >= 0) {
      Base.drive(fwd, Controlador.Axis2.position(), vex::velocityUnits::pct);
    }
    if (Controlador.Axis2.position() < 0) {
      Base.drive(reverse, Controlador.Axis2.position() * -1,
                 vex::velocityUnits::pct);
    }
  }
  return 0;
}
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) { task basecontrol(baseControl); }